package com.example.reif;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
public class subjectproperty {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ID;
	private String address;
	private int sqft;
	private int condition;
	private int exterior;
	private int garagecap;
	private int kitchen;
	private int bathrooms;
	private int flooring;
	private int fireplace;
	private int varsum;
	
	public subjectproperty() {}
	
	public subjectproperty(String address2, int sqft2, int exterior2, int condition2, int garagecap2, int kitchen2,
			int bathrooms2, int flooring2, int fireplace2) {
		address = address2;
		sqft = sqft2;
		condition = condition2;
		exterior = exterior2; 
		garagecap = garagecap2;
		kitchen = kitchen2;
		bathrooms = bathrooms2;
		flooring = flooring2;
		fireplace = fireplace2;
		varsum = condition2 + exterior2 + garagecap2 + kitchen2 + bathrooms2 + flooring2 + fireplace2;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getSqft() {
		return sqft;
	}

	public void setSqft(int sqft) {
		this.sqft = sqft;
	}

	public int getCondition() {
		return condition;
	}

	public void setCondition(int condition) {
		this.condition = condition;
	}

	public int getExterior() {
		return exterior;
	}

	public void setExterior(int exterior) {
		this.exterior = exterior;
	}

	public int getGaragecap() {
		return garagecap;
	}

	public void setGaragecap(int garagecap) {
		this.garagecap = garagecap;
	}

	public int getKitchen() {
		return kitchen;
	}

	public void setKitchen(int kitchen) {
		this.kitchen = kitchen;
	}

	public int getBathrooms() {
		return bathrooms;
	}

	public void setBathrooms(int bathrooms) {
		this.bathrooms = bathrooms;
	}

	public int getFlooring() {
		return flooring;
	}

	public void setFlooring(int flooring) {
		this.flooring = flooring;
	}

	public int getFireplace() {
		return fireplace;
	}

	public void setFireplace(int fireplace) {
		this.fireplace = fireplace;
	}

	public int getVarsum() {
		return varsum;
	}

	public void setVarsum(int varsum) {
		this.varsum = varsum;
	}


	
}
