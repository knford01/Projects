package com.example.reif;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class soldproperties {
	
	@Id
	private int ID;
	private int SQFT;
	private int List_Price;
	private int Sold_Price;
	private int Overall_Condition;
	private int Exterior;
	private int Garage_Capacity;
	private int Kitchen;
	private int Bathrooms;
	private int Floor_Covering;
	private int Fireplace;
	private int varsum;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getSQFT() {
		return SQFT;
	}
	public void setSQFT(int sQFT) {
		SQFT = sQFT;
	}
	public int getList_Price() {
		return List_Price;
	}
	public void setList_Price(int list_Price) {
		List_Price = list_Price;
	}
	public int getSold_Price() {
		return Sold_Price;
	}
	public void setSold_Price(int sold_Price) {
		Sold_Price = sold_Price;
	}
	public int getOverall_Condition() {
		return Overall_Condition;
	}
	public void setOverall_Condition(int overall_Condition) {
		Overall_Condition = overall_Condition;
	}
	public int getExterior() {
		return Exterior;
	}
	public void setExterior(int exterior) {
		Exterior = exterior;
	}
	public int getGarage_Capacity() {
		return Garage_Capacity;
	}
	public void setGarage_Capacity(int garage_Capacity) {
		Garage_Capacity = garage_Capacity;
	}
	public int getKitchen() {
		return Kitchen;
	}
	public void setKitchen(int kitchen) {
		Kitchen = kitchen;
	}
	public int getBathrooms() {
		return Bathrooms;
	}
	public void setBathrooms(int bathrooms) {
		Bathrooms = bathrooms;
	}
	public int getFloor_Covering() {
		return Floor_Covering;
	}
	public void setFloor_Covering(int floor_Covering) {
		Floor_Covering = floor_Covering;
	}
	public int getFireplace() {
		return Fireplace;
	}
	public void setFireplace(int fireplace) {
		Fireplace = fireplace;
	}
	public int getVarsum() {
		return varsum;
	}
	public void setVarsum(int varsum) {
		this.varsum = varsum;
	}
	
}
