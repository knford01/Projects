package com.example.reif;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
public class Suggested {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int purchaseprice;
	private int listprice;
	private int remodelcost;
	private int profit;
	private int condition;
	private int exterior;
	private int garage_capacity;
	private int kitchen;
	private int bathrooms;
	private int floor_covering;
	private int fireplace;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPurchaseprice() {
		return purchaseprice;
	}
	public void setPurchaseprice(int purchaseprice) {
		this.purchaseprice = purchaseprice;
	}
	public int getListprice() {
		return listprice;
	}
	public void setListprice(int listprice) {
		this.listprice = listprice;
	}
	public int getRemodelcost() {
		return remodelcost;
	}
	public void setRemodelcost(int remodelcost) {
		this.remodelcost = remodelcost;
	}
	public int getProfit() {
		return profit;
	}
	public void setProfit(int profit) {
		this.profit = profit;
	}
	public int getCondition() {
		return condition;
	}
	public void setCondition(int condition) {
		this.condition = condition;
	}
	public int getExterior() {
		return exterior;
	}
	public void setExterior(int exterior) {
		this.exterior = exterior;
	}
	public int getGarage_capacity() {
		return garage_capacity;
	}
	public void setGarage_capacity(int garage_capacity) {
		this.garage_capacity = garage_capacity;
	}
	public int getKitchen() {
		return kitchen;
	}
	public void setKitchen(int kitchen) {
		this.kitchen = kitchen;
	}
	public int getBathrooms() {
		return bathrooms;
	}
	public void setBathrooms(int bathrooms) {
		this.bathrooms = bathrooms;
	}
	
	public int getFloor_covering() {
		return floor_covering;
	}
	public void setFloor_covering(int floor_covering) {
		this.floor_covering = floor_covering;
	}
	public int getFireplace() {
		return fireplace;
	}
	public void setFireplace(int fireplace) {
		this.fireplace = fireplace;
	}
	
}
