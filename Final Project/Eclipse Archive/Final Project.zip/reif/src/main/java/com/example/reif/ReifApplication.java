package com.example.reif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReifApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReifApplication.class, args);
	}
}
