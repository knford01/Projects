package com.example.reif;

import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;


public interface subjectAPI extends CrudRepository<subjectproperty, Integer>{
	
	///////////////////////////////////////API FUCNTION TO GET ALL FROM SUBJECT PROPERTY TABLE///////////////////////////////////////

	@Query(value="SELECT * FROM [REIF].[dbo].[subjectproperty]", nativeQuery = true)
	List<subjectproperty> getaddress();
	
	///////////////////////////////////////API FUCNTION TO BUILD AND RETURN ANALYSIS///////////////////////////////////////
	
	@Modifying
	@Transactional
	@Query(value="select 3 as Address,\r\n" + 
			"	   max(list_price) as SQFT,\r\n" + 
			"	   max(Overall_Condition) - min(Overall_Condition) as Condition,\r\n" + 
			"	   max(exterior) - min(exterior) as Exterior,\r\n" + 
			"	   max(Garage_Capacity) - min(Garage_Capacity) as GarageCap,\r\n" + 
			"	   max(kitchen) - min(kitchen) as Kitchen,\r\n" + 
			"	   max(bathrooms) - min(bathrooms) as Bathrooms,\r\n" + 
			"	   max(floor_covering) - min(floor_covering) as Flooring,\r\n" + 
			"	   0 as Fireplace, max(VarSum) as VarSum, min(sold_price) as ID\r\n" + 
			"	   from soldproperties where SQFT = :xsqft and VarSum between (:xvar-3) and (:xvar+3)", nativeQuery = true)
	List<subjectproperty> getanswer(@Param("xsqft") int xsqft, @Param("xvar") int xvar);

	///////////////////////////////////////API FUCNTION TO POST A NEW SUBJECT PROPERTY///////////////////////////////////////
	
	@Modifying
	@Transactional
	@Query(value = "insert into subjectproperty (Address, SQFT, Condition, Exterior,"
			+ "GarageCap, Kitchen, Bathrooms, Flooring, Fireplace) values (:Address, :SQFT, :Condition,"
			+ ":Exterior, :GarageCap, :Kitchen, :Bathrooms, :Flooring, :Fireplace", nativeQuery = true)

	void postsubjectproperty(@Param("Address")String address, @Param("SQFT") int sqft, @Param("Condition") int condition,
			@Param("Exterior") int exterior, @Param("GarageCap") int garagecap, @Param("Kitchen") int kitchen,
			@Param("Bathrooms") int bathrooms, @Param("Flooring") int flooring, @Param("Fireplace") int fireplace);

	///////////////////////////////////////API FUCNTION TO UPDATE A SUBJECT PROPERTY///////////////////////////////////////
	
	@Modifying
	@Transactional
	@Query(value = "update [REIF].[dbo].[subjectproperty] set sqft=:sqft, Condition=:Condition, Exterior=:Exterior, GarageCap=:GarageCap,"
			+ "Kitchen=:Kitchen, Bathrooms=:Bathrooms, Flooring=:Flooring, Fireplace=:Fireplace where ID=:ID", nativeQuery = true)

	void updatesubject(@Param("ID")int ID, @Param("sqft") int sqft, @Param("Condition") int condition,
			@Param("Exterior") int exterior, @Param("GarageCap") int garagecap, @Param("Kitchen") int kitchen,
			@Param("Bathrooms") int bathrooms, @Param("Flooring") int flooring, @Param("Fireplace") int fireplace);
	
	///////////////////////////////////////API FUCNTION TO DELETE A SUBJECT PROPERTY///////////////////////////////////////
	
	@Modifying
	@Transactional
	@Query(value = "delete FROM [REIF].[dbo].[subjectproperty] where Address=:Address, SQFT=:SQFT, Condition=:Condition, Exterior=:Exterior, GarageCap=:GarageCap, "
			+ "Kitchen=:Kitchen, Bathrooms=:Bathrooms, Flooring=:Flooring, Fireplace=:Fireplace, varsum=:varsum, ID=:ID", nativeQuery = true)
	void deleteById(@Param("Address")String address, @Param("SQFT") int sqft, @Param("Condition") int condition,
			@Param("Exterior") int exterior, @Param("GarageCap") int garagecap, @Param("Kitchen") int kitchen,
			@Param("Bathrooms") int bathrooms, @Param("Flooring") int flooring, @Param("Fireplace") int fireplace, @Param("ID") int ID);


}
