package com.example.reif;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class multipliers {
	
	@Id
	private int id;
	private float condition;
	private float exterior;
	private int garage;
	private int kitchen;
	private int bathroom;
	private int flooring;
	private int fireplace;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getCondition() {
		return condition;
	}
	public void setCondition(float condition) {
		this.condition = condition;
	}
	public float getExterior() {
		return exterior;
	}
	public void setExterior(float exterior) {
		this.exterior = exterior;
	}
	public int getGarage() {
		return garage;
	}
	public void setGarage(int garage) {
		this.garage = garage;
	}
	public int getKitchen() {
		return kitchen;
	}
	public void setKitchen(int kitchen) {
		this.kitchen = kitchen;
	}
	public int getBathroom() {
		return bathroom;
	}
	public void setBathroom(int bathroom) {
		this.bathroom = bathroom;
	}
	public int getFlooring() {
		return flooring;
	}
	public void setFlooring(int flooring) {
		this.flooring = flooring;
	}
	public int getFireplace() {
		return fireplace;
	}
	public void setFireplace(int fireplace) {
		this.fireplace = fireplace;
	}
	
}
