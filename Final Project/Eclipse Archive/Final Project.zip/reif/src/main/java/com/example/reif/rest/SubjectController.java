package com.example.reif.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.reif.*;


@RestController
public class SubjectController {


	@Autowired
	subjectAPI autoSubject;
	
	@Autowired
	multiAPI automultipliers;


	///////////////////////////////////////GET ALL MAPPING CONTROLLER TO SUBJECTAPI///////////////////////////////////////
	
	@CrossOrigin(origins="*")
	@GetMapping(value = "/SubjectAllAddresses/")
	public List<subjectproperty> getaddress(){
		return autoSubject.getaddress();
	}
	
	///////////////////////////////////////GET ALL MAPPING CONTROLLER TO ANSWERS///////////////////////////////////////
	
	@CrossOrigin(origins="*")
	@GetMapping(value = "/SubjectAnswer/{xsqft}/{xvar}")
	public List<subjectproperty> getanswer(@PathVariable("xsqft") int xsqft, @PathVariable("xvar") int xvar){
		return autoSubject.getanswer(xsqft, xvar );
	}
	
    ///////////////////////////////////////GET ALL MAPPING CONTROLLER TO MULTIPLIERS TABLE ///////////////////////////////////////
	
	@CrossOrigin(origins="*")
	@GetMapping(value = "/MultipliersGetAll/")
	public List<multipliers> multipliersAll() {
		List<multipliers> answer = automultipliers.findAll();
		return answer;
	}
	
	///////////////////////////////////////GET MAPPING CONTROLLER TO POST THROUGH HAL///////////////////////////////////////
	
	@GetMapping(value = "/AddSubject/")
	@ResponseBody
	public subjectproperty Post( @RequestParam("Address") String Address, @RequestParam("SQFT") int SQFT,
			@RequestParam("Condition") int Condition, @RequestParam("Exterior") int Exterior,
			@RequestParam("GarageCap") int garagecap,
			@RequestParam("Kitchen") int Kitchen,
			@RequestParam("Bathrooms") int Bathrooms,
			@RequestParam("Flooring") int Flooring,
			@RequestParam("Fireplace") int Fireplace) { 

		subjectproperty ThisREIF = new subjectproperty(Address, SQFT, Condition, Exterior, garagecap, Kitchen, Bathrooms, Flooring, Fireplace);
		autoSubject.save(ThisREIF);
		return ThisREIF;
	}  
	
	///////////////////////////////////////POST MAPPING CONTROLLER TO API FOR POSTMAN///////////////////////////////////////
	
	@CrossOrigin(origins="*")
	@PostMapping(value = "/AddSubject/")
	@ResponseBody
	public subjectproperty Post1( @RequestParam("Address") String Address, @RequestParam("SQFT") int SQFT,
			@RequestParam("Condition") int Condition, @RequestParam("Exterior") int Exterior,
			@RequestParam("GarageCap") int garagecap,
			@RequestParam("Kitchen") int Kitchen,
			@RequestParam("Bathrooms") int Bathrooms,
			@RequestParam("Flooring") int Flooring,
			@RequestParam("Fireplace") int Fireplace) { 

		subjectproperty ThisREIF = new subjectproperty(Address, SQFT, Condition, Exterior, garagecap, Kitchen, Bathrooms, Flooring, Fireplace);
		autoSubject.save(ThisREIF);
		return ThisREIF;
	}  
	
	///////////////////////////////////////PUT MAPPING CONTROLLER TO UPDATE SUBJECT///////////////////////////////////////
	
	@CrossOrigin(origins="*")
	@PutMapping(value = "/UpdateSubject/{ID}/{sqft}/{Condition}/{Exterior}/{GarageCap}/{Kitchen}/{Bathrooms}/{Flooring}/{Fireplace}")
	@ResponseBody
	public void updateSubject(
			
			@PathVariable("ID") int ID ,@PathVariable("sqft") int sqft,
			@PathVariable("Condition") int Condition, @PathVariable("Exterior") int Exterior,
			@PathVariable("GarageCap") int garagecap,
			@PathVariable("Kitchen") int Kitchen,
			@PathVariable("Bathrooms") int Bathrooms,
			@PathVariable("Flooring") int Flooring,
			@PathVariable("Fireplace") int Fireplace) { 
			autoSubject.updatesubject(ID, sqft, Condition, Exterior, garagecap, Kitchen, Bathrooms, Flooring, Fireplace);
	} 
	
    ///////////////////////////////////////DELETE MAPPING CONTROLLER TO REMOVE A SUBJECT USING ID///////////////////////////////////////
	
	@DeleteMapping(value = "/SubjectDelete/{id}")
	public void SubjectDelete(@PathVariable("id") int id) {
		autoSubject.deleteById(id);
	}
	
	@DeleteMapping(value = "/SubjectDelete/{address}/{sqft}/{condition}/{exterior}/{garagecap}/{kitchen}/{bathroom}/{flooring}/{fireplace}/{varsum}/{id}")
	public void SubjectDelete(@RequestParam("Address") String Address, @RequestParam("SQFT") int SQFT,
			@RequestParam("Condition") int Condition, @RequestParam("Exterior") int Exterior,
			@RequestParam("GarageCap") int garagecap,
			@RequestParam("Kitchen") int Kitchen,
			@RequestParam("Bathrooms") int Bathrooms,
			@RequestParam("Flooring") int Flooring,
			@RequestParam("Fireplace") int Fireplace,
			@RequestParam("ID") int ID) {
			autoSubject.deleteById(Address, SQFT, Condition, Exterior, garagecap, Kitchen, Bathrooms, Flooring, Fireplace, ID);
		
	}
	
}
