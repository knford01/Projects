package com.example.reif;

import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Transactional;

@RepositoryRestResource
public interface soldpropAPI extends CrudRepository<soldproperties, Integer>{

	List<soldproperties> findByvarsum(int varsum);
	List<soldproperties> findByID(int id);
//	List<soldproperties> findByColor(String color);
//	List<soldproperties> findByName(String name);
//	
//	@Query(value = "select n.* from [saladingredients] si join salad s on s.id = si.sid join nuts n on isNut =1 and n.id = NutID", nativeQuery = true )
//	List <soldproperties> DemSaladNuts ();
//	
//	@Query(value = "select * from nuts where texture= :texture and color = :color", nativeQuery = true )
//		List <soldproperties> textureAndColor (@Param("texture")String Texture, @Param("color") String Color);
//	
//    List<soldproperties> findByTextureAndColor(String texture, String color);
//    
//    List<soldproperties> findByTextureOrColor(String texture, String color);
//    
//    @Modifying
//    @Transactional
//    @Query(value = "update nuts set texture = :newTexture where texture = :oldTexture", nativeQuery = true)
//    void updateByTexture(@Param("oldTexture")String oldT, @Param("newTexture")String newT);
	

}
